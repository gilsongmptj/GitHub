package org.example.model;

import java.time.LocalDate;
import java.time.LocalTime;


public class Servico {


    private Integer id;
    private LocalDate data;
    private LocalTime hora;
    private Double valor;
    private Praga praga;
    private Produto produto;
    private Equipamento equipamento;
    private Cliente cliente;


    public Servico() {

        this.valor = 0.0;
    }

    public Servico(LocalDate data, LocalTime hora, Praga praga, Produto produto, Equipamento equipamento, Cliente cliente) {

        this();

        this.data = data;
        this.hora = hora;
        this.praga = praga;
        this.produto = produto;
        this.equipamento = equipamento;
        this.cliente = cliente;
    }

    // Métodos getters e setters da classe
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public LocalDate getData() {
        return data;
    }

    public void setData(LocalDate data) {
        this.data = data;
    }

    public LocalTime getHora() {
        return hora;
    }

    public void setHora(LocalTime hora) {
        this.hora = hora;
    }

    public Double getValor() {
        return valor;
    }

    public void setValor(Double valor) {
        this.valor = valor;
    }

    public Praga getPraga() {
        return praga;
    }

    public void setPraga(Praga praga) {
        this.praga = praga;
    }

    public Produto getProduto() {
        return produto;
    }

    public void setProduto(Produto produto) {
        this.produto = produto;
    }

    public Equipamento getEquipamento() {
        return equipamento;
    }

    public void setEquipamento(Equipamento equipamento) {
        this.equipamento = equipamento;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    // Método para calcular o valor do serviço
    public void calcularValor() {}

}

