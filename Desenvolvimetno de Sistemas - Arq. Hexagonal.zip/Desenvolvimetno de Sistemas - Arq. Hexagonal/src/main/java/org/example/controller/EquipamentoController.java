package org.example.controller;

import org.example.ports.EquipamentoPort;

public class EquipamentoController implements EquipamentoPort {
}
