package org.example.adapters;

import org.example.ports.ServicoPort;

public class ServicoControllerAdapter implements ServicoPort {



}
