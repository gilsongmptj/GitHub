package org.example.adapters;

import org.example.ports.EquipamentoPort;

public class EquipamentoAdapter implements EquipamentoPort {
    public EquipamentoAdapter() {
    }
}

