package org.example.repository;

public interface ServiçoRepositoryAdapter {
}
