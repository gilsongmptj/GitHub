package org.example.controller;

import org.example.ports.PragaPort;

public class PragaController implements PragaPort {
}
