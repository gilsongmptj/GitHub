package org.example.adapters;

import org.example.controller.ClienteController;
import org.example.ports.ClientPort;

public class ClienteControllerAdapter implements ClientPort {
    @Override
    public <OrdemServico> OrdemServico ordemServico(OrdemServico ordemServico) {
        return null;
    }
}
