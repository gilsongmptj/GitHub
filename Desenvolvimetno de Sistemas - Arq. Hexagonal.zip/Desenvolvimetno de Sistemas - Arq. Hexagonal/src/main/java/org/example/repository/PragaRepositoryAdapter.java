package org.example.repository;

public interface PragaRepositoryAdapter {
}
