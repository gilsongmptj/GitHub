package org.example.ports;

public interface PragaPort {

}
