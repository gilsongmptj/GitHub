package org.example.adapters;

import org.example.ports.PragaPort;

public class PragaControllerAdapter implements PragaPort {

    public PragaControllerAdapter() {
    }
}

