package org.example.controller;

import org.example.ports.ServicoPort;

public class ServicoController implements ServicoPort {
}
