package org.example.controller;

import org.example.ports.ProdutoPort;

public class ProdutoControllerPort implements ProdutoPort {
}
