package org.example.repository;

public interface EquipamentoRepositoryAdapter {
}
