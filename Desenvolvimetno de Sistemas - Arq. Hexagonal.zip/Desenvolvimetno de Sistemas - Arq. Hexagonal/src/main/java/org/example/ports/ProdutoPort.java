package org.example.ports;

public interface ProdutoPort {
}
