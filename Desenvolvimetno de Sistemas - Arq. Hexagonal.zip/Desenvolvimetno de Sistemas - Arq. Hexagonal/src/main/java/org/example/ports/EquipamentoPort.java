package org.example.ports;

public interface EquipamentoPort {
}
