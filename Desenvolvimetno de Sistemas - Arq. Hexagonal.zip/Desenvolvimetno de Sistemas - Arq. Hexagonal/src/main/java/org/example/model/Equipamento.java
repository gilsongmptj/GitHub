package org.example.model;

public class Equipamento {
}
