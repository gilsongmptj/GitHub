package org.example.controller;

import org.example.ports.ClientPort;
import org.example.ports.ClienteRepositoryPort;



public class ClienteController<Cliente> implements ClientPort {



    private ClienteRepositoryPort clienteRepository;


    public void create( Cliente cliente ) {

    }


    public Cliente view( Integer id) {
        Cliente cliente = null;
        return null;
    }

    @Override
    public <OrdemServico> OrdemServico ordemServico(OrdemServico ordemServico) {
        return null;
    }
}
