package org.example.model;

public class Praga {

    private Integer id;
    private String nome;
    private String descricao;
    private Double taxa;
    private Servico servico;


    public Praga() {
        this.taxa = 0.0;
    }

    public Praga(String nome, String descricao, Double taxa) {
        this.nome = nome;
        this.descricao = descricao;
        this.taxa = taxa;
 ;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public Double getTaxa() {
        return taxa;
    }

    public void setTaxa(Double taxa) {
        this.taxa = taxa;
    }
    public Servico getServico() {
        return servico;
    }

    public void setServico(Servico servico) {
        this.servico = servico;
    }


}

