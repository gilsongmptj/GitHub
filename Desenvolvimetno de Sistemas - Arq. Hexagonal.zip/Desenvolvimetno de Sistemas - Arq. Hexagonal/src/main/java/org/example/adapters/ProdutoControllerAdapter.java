package org.example.adapters;

import org.example.ports.ProdutoPort;

public class ProdutoControllerAdapter implements ProdutoPort {


}
