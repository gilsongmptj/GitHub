package org.example.ports;

public interface ClienteRepositoryPort {
}
