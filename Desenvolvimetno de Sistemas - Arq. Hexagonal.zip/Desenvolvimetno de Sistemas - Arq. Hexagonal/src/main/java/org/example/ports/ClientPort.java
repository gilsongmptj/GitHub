package org.example.ports;

public interface ClientPort {
    <OrdemServico> OrdemServico ordemServico(OrdemServico ordemServico);
}
