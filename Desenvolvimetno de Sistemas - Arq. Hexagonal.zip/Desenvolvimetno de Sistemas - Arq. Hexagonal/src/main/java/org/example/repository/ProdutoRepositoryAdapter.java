package org.example.repository;

public interface ProdutoRepositoryAdapter {
}
